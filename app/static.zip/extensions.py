# Aqui você vai colocar db = SQLAlchemy() e login_manager = LoginManager() quando iniciar o sistema.
